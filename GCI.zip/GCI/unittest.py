import unittest
import sys,os

def add_angle(angle1:float, angle2:float)->float:
	""" Add two angles together, returning 0 to 360 degrees """ 
	ret = angle1 + angle2
	if ret > 360:
		ret -= 360
	return ret
	
class Test(unittest.TestCase):

    # Test if the function returns the correct answer in all the cases
	def test_equality(self):
		self.assertAlmostEqual(add_angle(120.2,340.6),100.8) # sum < multiple of 360
		self.assertAlmostEqual(add_angle(250.6,560.2),90.8)  # sum >= multiple of 360 - can be corrected with 'while' instead of 'if'
		
	# Test if the function returns the correct answer if the values are both negative
	def test_both_negative(self):
		self.assertAlmostEqual(add_angle(-100,-200),60)
		
	# Test if the function returns the correct answer if one of the values is negative
	def test_one_negative(self):
		self.assertAlmostEqual(add_angle(-100,78.5),338.5) # abs(negative) < abs(other operand)
		self.assertAlmostEqual(add_angle(-100,178.5),78.5) # abs(negative) > abs(other operand)
		
	# Test if the function types an error if one of the operands is missing	
	def test_missing_operand(self):
		with self.assertRaises(TypeError):   
			add_angle(370)
			
	# Test if the function types an error if one of the operands is not a number
	def test_invalid_input(self):
		with self.assertRaises(TypeError):
			add_angle(300, "a")
if __name__=='__main__':
	unittest.main()